import { useState, useEffect, useRef } from "react";
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer,
  ReferenceLine, CartesianGrid
} from "recharts";

/* ───────────── SOH design tokens ───────────── */
const C = {
  ink: "#0A1F44", panel: "#10294F", panel2: "#15325E", line: "#23477E",
  cream: "#F7F2EE", slate: "#7E92B5", gold: "#C19A3A",
  goldSoft: "rgba(193,154,58,0.16)", red: "#E2574C", redSoft: "rgba(226,87,76,0.14)",
  green: "#3FA776", greenSoft: "rgba(63,167,118,0.14)",
};
const mono = "ui-monospace, SFMono-Regular, Menlo, Consolas, monospace";
const sans = "-apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif";

/* ───────────── tracked universe ───────────── */
const PILL = "pill", INJ = "injection", LEGACY = "legacy", ADVICE = "advice";
const TRACKED = [
  { kw: "wegovy pill",               goal: PILL, base: 26, hero: true },
  { kw: "wegovy pills",              goal: PILL, base: 25 },
  { kw: "wegovy tablets",            goal: PILL, base: 43 },
  { kw: "wegovy pill uk",            goal: PILL, base: 20 },
  { kw: "buy wegovy pills",          goal: PILL, base: null },
  { kw: "oral semaglutide",          goal: PILL, base: null },
  { kw: "buy wegovy",                goal: INJ,  base: 9 },
  { kw: "buy wegovy online",         goal: INJ,  base: 14 },
  { kw: "buy wegovy uk",             goal: INJ,  base: 9 },
  { kw: "where can i buy wegovy uk", goal: INJ,  base: 7 },
];
const BASE_DATE = "2026-06-10";
const CLASS_PATH = {
  pill: "/online-doctor/weight-loss-pills/wegovy-pills/",
  injection: "/weight-loss/wegovy/",
  legacy: "/online-doctor/weight-loss/wegovy/",
  advice: "/health-advice/weight-loss/wegovy-pill/",
  other: "/",
};

const CHECKLIST = [
  { id: 1,  s: "CRIT", t: "Re-route “buy wegovy” intent off the pill page (titles, copy, internal anchors)" },
  { id: 2,  s: "CRIT", t: "301 legacy /online-doctor/weight-loss/wegovy/ → /weight-loss/wegovy/ + full legacy crawl" },
  { id: 3,  s: "CRIT", t: "Digital PR live — target 15+ referring domains to the pill page pre-MHRA" },
  { id: 4,  s: "HIGH", t: "Merge duplicate “how do the pills work” advice articles (301 the weaker)" },
  { id: 5,  s: "HIGH", t: "Strip commerce template bleed (£0.00 / Out of Stock / dispatch countdown / Saxenda modal)" },
  { id: 6,  s: "HIGH", t: "Remove Orlistat / Xenical / Alli price tables from the pill page" },
  { id: 7,  s: "HIGH", t: "Remove or nofollow outbound links to wegovy.com" },
  { id: 8,  s: "MED",  t: "Rewrite title tag + og tags (brand, availability hook, fix empty og:description)" },
  { id: 9,  s: "MED",  t: "Fix breadcrumb pointing at retired /medications/ URL" },
  { id: 10, s: "MED",  t: "Fix copy errors + contradictory contraception FAQ" },
  { id: 11, s: "MED",  t: "Expand FAQ to 20+ Qs with FAQPage schema (Mounjaro playbook)" },
  { id: 12, s: "MED",  t: "Template hygiene: raw tokens in DOM, “%” in archive titles, nav typos" },
  { id: 13, s: "LOW",  t: "CWV debt on weight templates (Lighthouse ≥80) + remove user-scalable=0" },
];

/* ───────────── helpers ───────────── */
const todayUK = () => new Date().toLocaleDateString("en-CA", { timeZone: "Europe/London" });

function classify(u) {
  if (!u) return "other";
  const s = String(u).toLowerCase();
  if (s.includes("weight-loss-pills/wegovy-pills")) return PILL;
  if (s.includes("medications/wegovy")) return LEGACY;
  if (s.includes("online-doctor/weight-loss/wegovy")) return LEGACY;
  if (s.includes("/weight-loss/wegovy")) return INJ;
  if (s.includes("health-advice")) return ADVICE;
  return "other";
}
const clsLabel = { pill: "PILL PAGE", injection: "INJECTION", legacy: "LEGACY URL", advice: "ADVICE", other: "OTHER" };
const clsColor = { pill: C.gold, injection: C.green, legacy: C.red, advice: C.slate, other: C.slate };

/* ── Anthropic API (plain — NO custom headers; the bridge rejects them) ── */
async function callClaude({ prompt, mcp = false, search = false }) {
  const body = {
    model: "claude-sonnet-4-20250514",
    max_tokens: 1000,
    messages: [{ role: "user", content: prompt }],
  };
  if (mcp) body.mcp_servers = [{ type: "url", url: "https://mcp.semrush.com/claude/v1/mcp", name: "semrush" }];
  if (search) body.tools = [{ type: "web_search_20250305", name: "web_search" }];
  let res;
  try {
    res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  } catch (e) {
    throw new Error("Network: " + (e.message || e));
  }
  let raw = "";
  try { raw = await res.text(); } catch (_) {}
  let data = null;
  try { data = JSON.parse(raw); } catch (_) {}
  if (!data) throw new Error(`HTTP ${res.status}: ${raw.slice(0, 160) || "empty response"}`);
  if (data.error) throw new Error(data.error.message || JSON.stringify(data.error).slice(0, 160));
  return data.content || [];
}
const textOf = content => (content || []).filter(b => b.type === "text").map(b => b.text).join("\n");

/* ── parse Semrush straight from MCP tool results (survives truncation) ── */
function toolResultTexts(content) {
  const out = [];
  for (const b of content || []) {
    if (b.type === "mcp_tool_result") {
      const parts = Array.isArray(b.content) ? b.content : [];
      const t = parts.map(p => (p && p.text) || "").join("\n");
      if (t) out.push(t);
    }
  }
  return out;
}
function parseSemrushBlob(t) {
  const res = { rows: [], bl: null };
  const clean = String(t).replace(/\\n/g, "\n");
  if (/NOTHING FOUND/i.test(clean)) res.bl = res.bl || { t: 0, d: 0 };
  const lines = clean.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  for (let i = 0; i < lines.length; i++) {
    const low = lines[i].toLowerCase();
    if (low.includes("keyword") && low.includes("position") && lines[i].includes(";")) {
      const cols = lines[i].split(";").map(s => s.trim().toLowerCase());
      const ki = cols.findIndex(c => c.startsWith("keyword"));
      const pi = cols.findIndex(c => c === "position");
      const vi = cols.findIndex(c => c.includes("volume"));
      const ui = cols.findIndex(c => c === "url");
      for (let j = i + 1; j < lines.length; j++) {
        if (!lines[j].includes(";")) break;
        const p = lines[j].split(";");
        const pos = parseInt(p[pi], 10);
        if (p[ki] && Number.isFinite(pos)) {
          res.rows.push({ k: p[ki].toLowerCase().trim(), p: pos, v: parseInt(p[vi], 10) || 0, u: (p[ui] || "").trim() });
        }
      }
    }
    if ((low.startsWith("total;") || low.includes("domains_num")) && lines[i + 1]) {
      const cols = lines[i].split(";").map(s => s.trim().toLowerCase());
      const vals = lines[i + 1].split(";");
      const ti = cols.indexOf("total"), di = cols.indexOf("domains_num");
      const tot = parseInt(vals[ti], 10), dom = parseInt(vals[di], 10);
      if (Number.isFinite(dom) || Number.isFinite(tot)) res.bl = { t: tot || 0, d: dom || 0 };
    }
  }
  return res;
}

/* ── line-format + regex parsers (truncation-proof) ── */
function parseLines(text, tag) {
  // lines like: WP|1|domain.com|https://...
  const out = [];
  String(text || "").split(/\r?\n/).forEach(l => {
    const p = l.trim().split("|");
    if (p[0] === tag && p[2]) out.push({ d: (p[2] || "").replace(/^www\./, ""), u: p[3] || "" });
  });
  return out;
}
function parseRowLines(text) {
  // lines like: ROW|wegovy pills|3|/path   or   ROW|wegovy pills|none
  const out = [];
  String(text || "").split(/\r?\n/).forEach(l => {
    const p = l.trim().split("|");
    if (p[0] === "ROW" && p[1]) {
      const pos = parseInt(p[2], 10);
      if (Number.isFinite(pos)) out.push({ k: p[1].toLowerCase().trim(), p: pos, v: 0, u: p[3] || "" });
    }
  });
  return out;
}
function extractDomains(text) {
  const urls = [...String(text || "").matchAll(/https?:\/\/[^\s"')\]]+/g)].map(m => m[0]);
  const seen = new Set(); const out = [];
  for (const u of urls) {
    try {
      const d = new URL(u).hostname.replace(/^www\./, "");
      if (d.includes("anthropic") || d.includes("googleapis")) continue;
      if (!seen.has(d)) { seen.add(d); out.push({ d, u }); }
    } catch (_) {}
  }
  return out.slice(0, 7);
}

/* ── prompts ── */
const P_PING = `Reply with exactly: OK`;
const P_A = `You have Semrush MCP tools. Run the report named "domain_organic" (call a schema/help tool first if required) with: database "uk", domain "www.simpleonlinepharmacy.co.uk", display_filter "+|Ph|Co|wegovy", display_sort "nq_desc", display_limit 25, export_columns Ph,Po,Nq,Ur. After the tool returns, reply with just: DONE`;
const P_B = `You have Semrush MCP tools. 1) Run report "domain_organic" with database "uk", domain "www.simpleonlinepharmacy.co.uk", display_filter "+|Ph|Co|semaglutide", display_sort "nq_desc", display_limit 10, export_columns Ph,Po,Nq,Ur. 2) Run report "backlinks_overview" with target "https://www.simpleonlinepharmacy.co.uk/online-doctor/weight-loss-pills/wegovy-pills/", target_type "url", export_columns total,domains_num (NOTHING FOUND means zero). After both tools return, reply with just: DONE`;
const P_C = `Use the web_search tool twice: first search "wegovy pill", then search "buy wegovy". Then reply in EXACTLY this plain-text line format and nothing else — one line per result, up to 7 per query, in result order:
WP|1|domain.com|https://full-url
WP|2|...
BW|1|domain.com|https://full-url
BW|2|...`;
const P_D = `Use the web_search tool three times with these exact queries: "wegovy pills", "buy wegovy online", "buy wegovy uk". For each query, check whether any result is from simpleonlinepharmacy.co.uk. Reply ONLY in this plain-text line format, one line per query, nothing else:
ROW|wegovy pills|<rank number among results, or the word none>|<sop url path or blank>
ROW|buy wegovy online|<rank or none>|<path>
ROW|buy wegovy uk|<rank or none>|<path>`;

async function semrushCall(prompt) {
  const content = await callClaude({ prompt, mcp: true });
  const blobs = toolResultTexts(content);
  const agg = { rows: [], bl: null };
  for (const b of blobs) {
    const r = parseSemrushBlob(b);
    agg.rows.push(...r.rows);
    if (r.bl) agg.bl = r.bl;
  }
  if (!agg.rows.length && !agg.bl) throw new Error("Semrush tools returned no data (raw: " + (blobs.join(" ").slice(0, 120) || textOf(content).slice(0, 120) || "empty") + ")");
  return { ...agg, raw: blobs.join("\n").slice(0, 400) };
}
async function withRetry(fn) {
  try { return await fn(); }
  catch (_) { await new Promise(r => setTimeout(r, 1200)); return await fn(); }
}

/* ── snapshot math ── */
function buildSnapshot({ rows, bl, serp, mode, blStale }) {
  const clean = (rows || [])
    .filter(r => r && r.k && Number.isFinite(+r.p))
    .map(r => ({ k: String(r.k).toLowerCase().trim(), p: +r.p, v: +r.v || 0, u: r.u || "", c: r.c || classify(r.u) }));
  const best = {};
  TRACKED.forEach(({ kw }) => {
    const hits = clean.filter(r => r.k === kw);
    if (!hits.length) { best[kw] = null; return; }
    const top = hits.reduce((a, b) => (a.p <= b.p ? a : b));
    best[kw] = { p: top.p, c: top.c, u: top.u, n: new Set(hits.map(h => h.u || h.c)).size };
  });
  const bwInj = clean.filter(r => r.k === "buy wegovy" && r.c === INJ);
  const m = {
    pill: best["wegovy pill"]?.p ?? null,
    bwInj: bwInj.length ? Math.min(...bwInj.map(h => h.p)) : null,
    blD: bl?.d ?? 0, blT: bl?.t ?? 0,
  };
  const flags = {
    wrong: TRACKED.some(t => t.goal === INJ && best[t.kw] && best[t.kw].c === PILL),
    legacy: clean.some(r => r.c === LEGACY),
    cann: TRACKED.filter(t => best[t.kw] && best[t.kw].n > 1).length,
  };
  return { date: todayUK(), ts: Date.now(), rows: clean, best, m, flags, serp: serp || null, mode: mode || "semrush", blStale: !!blStale };
}
const streak = (snaps, fn) => { let n = 0; for (let i = snaps.length - 1; i >= 0; i--) { if (fn(snaps[i])) n++; else break; } return n; };

/* ── UI atoms ── */
const Eyebrow = ({ children, color = C.slate }) => (
  <div style={{ fontFamily: sans, fontSize: 10, letterSpacing: "0.18em", color, textTransform: "uppercase", fontWeight: 700 }}>{children}</div>
);
const Delta = ({ d }) => {
  if (d === null || d === undefined || Number.isNaN(d)) return <span style={{ color: C.slate, fontFamily: mono, fontSize: 12 }}>–</span>;
  if (d === 0) return <span style={{ color: C.slate, fontFamily: mono, fontSize: 12 }}>=</span>;
  const up = d > 0;
  return <span style={{ color: up ? C.green : C.red, fontFamily: mono, fontSize: 12, fontWeight: 700 }}>{up ? "▲" : "▼"}{Math.abs(d)}</span>;
};
const Chip = ({ text, color, bg }) => (
  <span style={{ fontFamily: sans, fontSize: 10, fontWeight: 700, letterSpacing: "0.08em", color, background: bg, padding: "3px 8px", borderRadius: 3 }}>{text}</span>
);

/* ───────────── main ───────────── */
export default function WegovySentinel() {
  const [snaps, setSnaps] = useState([]);
  const [checks, setChecks] = useState({});
  const [running, setRunning] = useState(false);
  const [steps, setSteps] = useState([]);
  const [err, setErr] = useState(null);
  const [diag, setDiag] = useState(null);
  const [showDiag, setShowDiag] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showManual, setShowManual] = useState(false);
  const [manual, setManual] = useState({});
  const [manualBl, setManualBl] = useState("");
  const ranRef = useRef(false);

  useEffect(() => {
    (async () => {
      try { const r = await window.storage.get("sentinel:snapshots"); if (r) setSnaps(JSON.parse(r.value)); } catch (_) {}
      try { const r = await window.storage.get("sentinel:checklist"); if (r) setChecks(JSON.parse(r.value)); } catch (_) {}
      setLoaded(true);
    })();
  }, []);

  const latest = snaps[snaps.length - 1] || null;
  const prev = snaps[snaps.length - 2] || null;
  const today = todayUK();
  const ranToday = latest?.date === today;

  useEffect(() => {
    if (loaded && !ranToday && !running && !ranRef.current) { ranRef.current = true; runDaily(); }
  }, [loaded]); // eslint-disable-line

  async function persistSnaps(next) {
    const capped = next.slice(-180);
    setSnaps(capped);
    try { await window.storage.set("sentinel:snapshots", JSON.stringify(capped)); } catch (_) {}
  }
  async function toggleCheck(id) {
    const next = { ...checks, [id]: !checks[id] };
    setChecks(next);
    try { await window.storage.set("sentinel:checklist", JSON.stringify(next)); } catch (_) {}
  }

  function seedManual() {
    const m = {};
    TRACKED.forEach(t => {
      const cur = latest?.best?.[t.kw];
      m[t.kw] = { p: cur?.p ?? t.base ?? "", c: cur?.c ?? t.goal };
    });
    setManual(m);
    setManualBl(String(latest?.m?.blD ?? 0));
    setShowManual(true);
  }
  async function saveManual() {
    const rows = [];
    TRACKED.forEach(t => {
      const e = manual[t.kw];
      const pos = parseInt(e?.p, 10);
      if (Number.isFinite(pos) && pos > 0) rows.push({ k: t.kw, p: pos, v: 0, u: CLASS_PATH[e.c] || "/", c: e.c });
    });
    const snap = buildSnapshot({
      rows,
      bl: { t: parseInt(manualBl, 10) || 0, d: parseInt(manualBl, 10) || 0 },
      serp: latest?.serp || null,
      mode: "manual",
    });
    await persistSnaps(snaps.filter(s => s.date !== snap.date).concat([snap]));
    setShowManual(false);
    setErr(null);
  }

  async function runDaily() {
    setRunning(true); setErr(null); setDiag(null);
    const st = [
      { k: "P", label: "API bridge self-test", s: "run" },
      { k: "A", label: "Semrush — Wegovy positions", s: "wait" },
      { k: "B", label: "Semrush — semaglutide + backlinks", s: "wait" },
      { k: "C", label: "Live SERP — “wegovy pill” / “buy wegovy”", s: "wait" },
    ];
    setSteps([...st]);
    const diagInfo = {};
    /* 0 ── ping */
    try {
      const ping = textOf(await callClaude({ prompt: P_PING }));
      diagInfo.ping = ping.slice(0, 40);
      st[0].s = "ok";
    } catch (e) {
      st[0].s = "fail"; setSteps([...st]);
      diagInfo.ping = "FAIL: " + (e.message || e);
      setDiag(diagInfo);
      setErr("The Claude API bridge is unavailable in this session (self-test failed). Close and reopen the artifact, or log today by hand below.");
      seedManual();
      setRunning(false);
      return;
    }
    setSteps([...st]);
    /* 1 ── Semrush legs */
    let mode = "semrush", rows = [], bl = null, blStale = false;
    try {
      st[1].s = "run"; setSteps([...st]);
      const a = await withRetry(() => semrushCall(P_A));
      st[1].s = "ok"; st[2].s = "run"; setSteps([...st]);
      const b = await withRetry(() => semrushCall(P_B));
      st[2].s = "ok"; setSteps([...st]);
      rows = [...a.rows, ...b.rows]; bl = b.bl;
      diagInfo.semrush = { a: a.raw, b: b.raw };
    } catch (e) {
      if (st[1].s !== "ok") st[1].s = "fail";
      st[2].s = "fail"; setSteps([...st]);
      diagInfo.semrushError = e.message || String(e);
      mode = "search";
    }
    /* 2 ── SERP leg */
    st[3].s = "run"; setSteps([...st]);
    let serp = null;
    try {
      const cTxt = textOf(await callClaude({ prompt: P_C, search: true }));
      let wp = parseLines(cTxt, "WP"), bw = parseLines(cTxt, "BW");
      if (!wp.length && !bw.length) { wp = extractDomains(cTxt); bw = []; }
      if (wp.length || bw.length) serp = { wp, bw };
      st[3].s = serp ? "ok" : "warn";
      diagInfo.serp = cTxt.slice(0, 200);
    } catch (e) { st[3].s = "warn"; diagInfo.serpError = e.message || String(e); }
    setSteps([...st]);
    /* 3 ── search-mode synthesis */
    if (mode === "search") {
      try {
        const dTxt = textOf(await callClaude({ prompt: P_D, search: true }));
        diagInfo.fallback = dTxt.slice(0, 200);
        const extra = parseRowLines(dTxt);
        const fromSerp = [];
        const scan = (arr, kw) => (arr || []).forEach((r, i) => {
          if (((r.d || "") + (r.u || "")).includes("simpleonlinepharmacy")) fromSerp.push({ k: kw, p: i + 1, v: 0, u: r.u || "" });
        });
        scan(serp?.wp, "wegovy pill"); scan(serp?.bw, "buy wegovy");
        rows = [...extra, ...fromSerp];
        bl = { t: latest?.m?.blT ?? 0, d: latest?.m?.blD ?? 0 };
        blStale = true;
      } catch (e) {
        diagInfo.fallbackError = e.message || String(e);
      }
      if (!rows.length && !serp) {
        setDiag(diagInfo);
        setErr("Semrush is down and the search fallback found nothing usable. Log today by hand below so the streak survives, then check the Semrush connector (Settings → Connectors → Semrush → reconnect).");
        seedManual();
        setRunning(false);
        return;
      }
    }
    const snap = buildSnapshot({ rows, bl, serp, mode, blStale });
    await persistSnaps(snaps.filter(s => s.date !== snap.date).concat([snap]));
    setDiag(diagInfo);
    if (mode === "search") setErr("Semrush connector unavailable — ran in SEARCH SAMPLE mode (approximate). Reconnect Semrush in Settings → Connectors for full data.");
    setRunning(false);
  }

  /* derived */
  const pillPos = latest?.m?.pill ?? null;
  const pillPrev = prev?.m?.pill ?? null;
  const pillBase = 26;
  const pageOne = pillPos !== null && pillPos <= 10;
  const target = pillPos !== null && pillPos <= 3;
  const wrongStreak = streak(snaps, s => s.flags?.wrong);
  const legacyStreak = streak(snaps, s => s.flags?.legacy);
  const blD = latest?.m?.blD ?? 0;
  const daysTracked = snaps.length;
  const chart = snaps.map(s => ({ d: s.date.slice(5), pill: s.m?.pill ?? null, bwInj: s.m?.bwInj ?? null }));
  const fmtD = d => (d === null || d === undefined ? "–" : d === 0 ? "=" : (d > 0 ? "▲" : "▼") + Math.abs(d));

  function digest() {
    const L = [];
    L.push(`WEGOVY SENTINEL — ${latest ? latest.date : today}${latest?.mode && latest.mode !== "semrush" ? ` (${latest.mode} mode)` : ""}`);
    L.push(`wegovy pill: ${pillPos ? "P" + pillPos : "n/a"} (${fmtD(pillPrev !== null && pillPos !== null ? pillPrev - pillPos : null)} vs prev · ${fmtD(pillPos !== null ? pillBase - pillPos : null)} vs baseline P26)${pageOne ? " — PAGE ONE ✅" : ""}`);
    const bw = latest?.best?.["buy wegovy"];
    if (bw) L.push(`buy wegovy: P${bw.p} via ${clsLabel[bw.c]}${bw.c === PILL ? " ⚠️ WRONG PAGE" : ""}`);
    if (latest?.flags?.wrong) L.push(`🔴 Wrong-page routing live — day ${wrongStreak}`);
    if (latest?.flags?.legacy) L.push(`🔴 Legacy URL still ranking — day ${legacyStreak}`);
    if (latest?.flags?.cann) L.push(`🟡 ${latest.flags.cann} keywords cannibalised`);
    L.push(`Backlinks: ${blD} referring domains${latest?.blStale ? " (last known)" : ""} · target 15`);
    L.push(`Remediation: ${CHECKLIST.filter(c => checks[c.id]).length}/${CHECKLIST.length} closed`);
    return L.join("\n");
  }
  async function copyDigest() {
    try { await navigator.clipboard.writeText(digest()); setCopied(true); setTimeout(() => setCopied(false), 1600); } catch (_) {}
  }
  const altPct = p => Math.min(100, Math.max(0, ((Math.min(p, 30) - 1) / 29) * 100));
  const modeBadge = latest?.mode === "search" ? { t: "SEARCH SAMPLE", bg: C.gold } : latest?.mode === "manual" ? { t: "MANUAL", bg: C.slate } : null;

  const inputStyle = {
    fontFamily: mono, fontSize: 13, width: 64, background: C.ink, color: C.cream,
    border: `1px solid ${C.line}`, borderRadius: 4, padding: "6px 8px",
  };
  const selectStyle = { ...inputStyle, width: 120 };

  return (
    <div style={{ minHeight: "100vh", background: C.ink, color: C.cream, fontFamily: sans, padding: "0 0 48px" }}>
      {/* command strip */}
      <div style={{ borderBottom: `1px solid ${C.line}`, padding: "16px 20px", display: "flex", flexWrap: "wrap", alignItems: "center", gap: 12 }}>
        <div style={{ flex: "1 1 240px", minWidth: 220 }}>
          <div style={{ fontFamily: mono, fontWeight: 700, fontSize: 18, letterSpacing: "0.06em" }}>
            WEGOVY <span style={{ color: C.gold }}>SENTINEL</span>
            {modeBadge && <span style={{ marginLeft: 8 }}><Chip text={modeBadge.t} color={C.ink} bg={modeBadge.bg} /></span>}
          </div>
          <div style={{ fontSize: 11, color: C.slate, marginTop: 2 }}>Daily rank patrol · simpleonlinepharmacy.co.uk · runs until page one</div>
        </div>
        <div style={{ textAlign: "right", fontFamily: mono, fontSize: 11, color: C.slate }}>
          <div>{today} (UK)</div>
          <div>{ranToday ? "today’s patrol complete" : "today’s patrol pending"} · day {daysTracked || "0"}</div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={seedManual} style={{ fontFamily: mono, fontSize: 11, background: C.panel2, color: C.cream, border: `1px solid ${C.line}`, borderRadius: 4, padding: "10px 12px", cursor: "pointer" }}>
            MANUAL
          </button>
          <button onClick={runDaily} disabled={running} style={{
            fontFamily: mono, fontSize: 12, fontWeight: 700, letterSpacing: "0.06em",
            background: running ? C.panel2 : C.gold, color: running ? C.slate : C.ink,
            border: "none", borderRadius: 4, padding: "10px 16px", cursor: running ? "default" : "pointer",
          }}>
            {running ? "PATROLLING…" : ranToday ? "RE-RUN PATROL" : "RUN TODAY’S PATROL"}
          </button>
        </div>
      </div>

      {/* run status / error / diagnostics */}
      {(running || err || steps.length > 0) && (
        <div style={{ padding: "10px 20px", borderBottom: `1px solid ${C.line}` }}>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 14, alignItems: "center" }}>
            {steps.map(s => (
              <div key={s.k} style={{ fontFamily: mono, fontSize: 11, color: s.s === "ok" ? C.green : s.s === "fail" ? C.red : s.s === "warn" ? C.gold : C.slate }}>
                {s.s === "ok" ? "●" : s.s === "fail" ? "✕" : s.s === "warn" ? "◐" : s.s === "run" ? "◌" : "○"} {s.label}
              </div>
            ))}
            {diag && (
              <button onClick={() => setShowDiag(!showDiag)} style={{ fontFamily: mono, fontSize: 11, color: C.slate, background: "none", border: `1px solid ${C.line}`, borderRadius: 3, padding: "2px 8px", cursor: "pointer" }}>
                {showDiag ? "hide diagnostics" : "diagnostics"}
              </button>
            )}
          </div>
          {err && <div style={{ fontFamily: mono, fontSize: 11, color: C.gold, marginTop: 6, lineHeight: 1.5 }}>{err}</div>}
          {showDiag && diag && (
            <pre style={{ marginTop: 8, padding: 10, background: C.panel2, borderRadius: 4, fontSize: 10, color: C.slate, whiteSpace: "pre-wrap", maxHeight: 180, overflow: "auto" }}>
              {JSON.stringify(diag, null, 1).slice(0, 1400)}
            </pre>
          )}
        </div>
      )}

      {/* manual entry */}
      {showManual && (
        <div style={{ margin: "16px 20px 0", background: C.panel, border: `1px solid ${C.gold}`, borderRadius: 8, padding: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 8 }}>
            <Eyebrow color={C.gold}>Manual patrol — key in from Semrush / GSC, blank = not ranking</Eyebrow>
            <button onClick={() => setShowManual(false)} style={{ fontFamily: mono, fontSize: 11, color: C.slate, background: "none", border: "none", cursor: "pointer" }}>close ✕</button>
          </div>
          <div style={{ marginTop: 10, display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(290px, 1fr))", gap: 8 }}>
            {TRACKED.map(t => (
              <div key={t.kw} style={{ display: "flex", alignItems: "center", gap: 8, background: C.panel2, borderRadius: 6, padding: "8px 10px" }}>
                <span style={{ fontSize: 12, flex: 1 }}>{t.kw}</span>
                <input
                  style={inputStyle} inputMode="numeric" placeholder="P"
                  value={manual[t.kw]?.p ?? ""}
                  onChange={e => setManual({ ...manual, [t.kw]: { ...(manual[t.kw] || { c: t.goal }), p: e.target.value.replace(/[^0-9]/g, "") } })}
                />
                <select
                  style={selectStyle}
                  value={manual[t.kw]?.c ?? t.goal}
                  onChange={e => setManual({ ...manual, [t.kw]: { ...(manual[t.kw] || {}), c: e.target.value } })}
                >
                  <option value="pill">pill page</option>
                  <option value="injection">injection</option>
                  <option value="legacy">legacy URL</option>
                  <option value="advice">advice</option>
                  <option value="other">other</option>
                </select>
              </div>
            ))}
            <div style={{ display: "flex", alignItems: "center", gap: 8, background: C.panel2, borderRadius: 6, padding: "8px 10px" }}>
              <span style={{ fontSize: 12, flex: 1 }}>backlink referring domains (pill page)</span>
              <input style={inputStyle} inputMode="numeric" value={manualBl} onChange={e => setManualBl(e.target.value.replace(/[^0-9]/g, ""))} />
            </div>
          </div>
          <button onClick={saveManual} style={{ marginTop: 12, fontFamily: mono, fontSize: 12, fontWeight: 700, background: C.gold, color: C.ink, border: "none", borderRadius: 4, padding: "10px 16px", cursor: "pointer" }}>
            SAVE MANUAL PATROL
          </button>
        </div>
      )}

      {/* mission banner */}
      {pillPos !== null && (
        <div style={{
          margin: "16px 20px 0", padding: "12px 16px", borderRadius: 6,
          background: target ? C.greenSoft : pageOne ? C.goldSoft : C.redSoft,
          border: `1px solid ${target ? C.green : pageOne ? C.gold : C.red}`,
          fontFamily: mono, fontSize: 12, fontWeight: 700,
          color: target ? C.green : pageOne ? C.gold : C.red,
        }}>
          {target ? "TARGET ACHIEVED — P1–3 secured. Hold through MHRA decision."
            : pageOne ? "PAGE ONE REACHED ✅ — new mission: P1–3 before MHRA decision."
            : `MISSION: page one for “wegovy pill” before MHRA decision · currently P${pillPos} · ${pillPos - 10} positions to the line`}
        </div>
      )}

      <div style={{ display: "flex", flexWrap: "wrap", gap: 16, padding: "16px 20px 0" }}>
        {/* altimeter */}
        <div style={{ flex: "0 0 200px", background: C.panel, border: `1px solid ${C.line}`, borderRadius: 8, padding: 16, minWidth: 180 }}>
          <Eyebrow color={C.gold}>“wegovy pill” · altitude</Eyebrow>
          <div style={{ display: "flex", gap: 12, marginTop: 12 }}>
            <div style={{ position: "relative", width: 44, height: 300, background: C.panel2, borderRadius: 4, overflow: "hidden" }}>
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: `${altPct(10)}%`, background: C.goldSoft, borderBottom: `1px dashed ${C.gold}` }} />
              <div style={{ position: "absolute", top: `${altPct(3)}%`, left: 0, right: 0, borderTop: `2px solid ${C.green}` }} />
              <div style={{ position: "absolute", top: `${altPct(pillBase)}%`, left: 0, right: 0, borderTop: `1px dotted ${C.slate}` }} />
              {pillPos !== null && (
                <div style={{
                  position: "absolute", top: `calc(${altPct(pillPos)}% - 9px)`, left: 4, right: 4, height: 18,
                  background: pageOne ? C.gold : C.red, borderRadius: 3, display: "flex", alignItems: "center", justifyContent: "center",
                  color: C.ink, fontFamily: mono, fontWeight: 800, fontSize: 11,
                }}>P{pillPos}</div>
              )}
            </div>
            <div style={{ display: "flex", flexDirection: "column", justifyContent: "space-between", height: 300, fontFamily: mono, fontSize: 10, color: C.slate }}>
              <span style={{ color: C.gold }}>P1</span>
              <span style={{ color: C.green }}>P3 target</span>
              <span style={{ color: C.gold }}>P10 · page one</span>
              <span>P26 baseline</span>
              <span>P30+</span>
            </div>
          </div>
          <div style={{ marginTop: 12, fontFamily: mono, fontSize: 12 }}>
            <span style={{ color: C.slate }}>vs prev </span><Delta d={pillPrev !== null && pillPos !== null ? pillPrev - pillPos : null} />
            <span style={{ color: C.slate, marginLeft: 10 }}>vs base </span><Delta d={pillPos !== null ? pillBase - pillPos : null} />
          </div>
        </div>

        {/* flags */}
        <div style={{ flex: "1 1 320px", minWidth: 280, display: "flex", flexDirection: "column", gap: 10 }}>
          <Eyebrow>Structural audit — re-checked every patrol</Eyebrow>
          {[
            { on: latest?.flags?.wrong, days: wrongStreak,
              ok: "“Buy wegovy” intent now served by the injection page",
              bad: "Wrong-page routing LIVE — pill page still ranks for buy-intent terms" },
            { on: latest?.flags?.legacy, days: legacyStreak,
              ok: "Legacy injection URL no longer ranking — migration consolidated",
              bad: "Legacy /online-doctor/weight-loss/wegovy/ STILL ranking — migration unfinished" },
            { on: (latest?.flags?.cann ?? 0) > 0, days: streak(snaps, s => (s.flags?.cann ?? 0) > 0),
              ok: "One URL per keyword — cannibalisation cleared",
              bad: `${latest?.flags?.cann ?? 0} keywords cannibalised (2+ SOP URLs ranking)` },
            { on: blD < 15, days: null,
              ok: `Link target met — ${blD} referring domains`,
              bad: `Backlinks: ${blD}${latest?.blStale ? " (last known)" : ""} referring domains to the pill page · target 15` },
          ].map((f, i) => (
            <div key={i} style={{
              background: f.on ? C.redSoft : C.greenSoft, border: `1px solid ${f.on ? C.red : C.green}`,
              borderRadius: 6, padding: "10px 12px", display: "flex", justifyContent: "space-between", gap: 10, alignItems: "center",
            }}>
              <div style={{ fontSize: 12.5, color: f.on ? "#F4B3AD" : "#A9DCC4", lineHeight: 1.35 }}>{f.on ? f.bad : f.ok}</div>
              {f.on && f.days ? <Chip text={`DAY ${f.days}`} color={C.ink} bg={C.red} /> : !f.on ? <Chip text="CLEAR" color={C.ink} bg={C.green} /> : null}
            </div>
          ))}
          {!latest && (
            <div style={{ fontSize: 12, color: C.slate, lineHeight: 1.5 }}>
              No patrol on record yet. The first run establishes day zero against the 10 June audit baseline
              (pill page P26, wrong-page routing live, legacy URL live, 0 backlinks).
            </div>
          )}
        </div>

        {/* trend */}
        <div style={{ flex: "1 1 340px", minWidth: 300, background: C.panel, border: `1px solid ${C.line}`, borderRadius: 8, padding: 16 }}>
          <Eyebrow>Trajectory — lower is better</Eyebrow>
          {chart.length >= 2 ? (
            <div style={{ height: 280, marginTop: 8 }}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chart} margin={{ top: 10, right: 8, left: -18, bottom: 0 }}>
                  <CartesianGrid stroke={C.line} strokeDasharray="2 4" />
                  <XAxis dataKey="d" tick={{ fill: C.slate, fontSize: 10, fontFamily: mono }} stroke={C.line} />
                  <YAxis reversed domain={[1, 30]} tick={{ fill: C.slate, fontSize: 10, fontFamily: mono }} stroke={C.line} />
                  <Tooltip contentStyle={{ background: C.panel2, border: `1px solid ${C.line}`, fontFamily: mono, fontSize: 11, color: C.cream }} />
                  <ReferenceLine y={10} stroke={C.gold} strokeDasharray="4 4" />
                  <ReferenceLine y={3} stroke={C.green} strokeDasharray="4 4" />
                  <Line type="monotone" dataKey="pill" name="wegovy pill (pill page)" stroke={C.gold} strokeWidth={2} dot={{ r: 2.5 }} connectNulls />
                  <Line type="monotone" dataKey="bwInj" name="buy wegovy (injection)" stroke={C.green} strokeWidth={2} dot={{ r: 2.5 }} connectNulls />
                </LineChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div style={{ height: 280, display: "flex", alignItems: "center", justifyContent: "center", color: C.slate, fontSize: 12, textAlign: "center", padding: 16 }}>
              Trend appears after two patrols.<br />Gold = “wegovy pill” · Green = “buy wegovy” (injection page).
            </div>
          )}
        </div>
      </div>

      {/* keyword table */}
      <div style={{ margin: "16px 20px 0", background: C.panel, border: `1px solid ${C.line}`, borderRadius: 8, overflow: "hidden" }}>
        <div style={{ padding: "12px 16px", borderBottom: `1px solid ${C.line}`, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
          <Eyebrow>Tracked cluster — best SOP position per keyword{latest?.mode === "search" ? " (search-sample, approximate)" : latest?.mode === "manual" ? " (manual entry)" : ""}</Eyebrow>
          <button onClick={copyDigest} style={{ fontFamily: mono, fontSize: 11, background: C.panel2, color: copied ? C.green : C.cream, border: `1px solid ${C.line}`, borderRadius: 4, padding: "6px 10px", cursor: "pointer" }}>
            {copied ? "COPIED ✓" : "COPY DAILY DIGEST"}
          </button>
        </div>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5, minWidth: 640 }}>
            <thead>
              <tr style={{ color: C.slate, fontFamily: mono, fontSize: 10, textAlign: "left" }}>
                {["KEYWORD", "POS", "Δ PREV", "Δ BASE", "SERVED BY", "URLS", "STATUS"].map(h => (
                  <th key={h} style={{ padding: "8px 14px", borderBottom: `1px solid ${C.line}`, letterSpacing: "0.1em" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {TRACKED.map((t, i) => {
                const cur = latest?.best?.[t.kw] || null;
                const pv = prev?.best?.[t.kw]?.p ?? null;
                const pos = cur?.p ?? null;
                const wrong = t.goal === INJ && cur?.c === PILL;
                const legacy = cur?.c === LEGACY;
                return (
                  <tr key={t.kw} style={{ background: i % 2 ? "rgba(255,255,255,0.02)" : "transparent" }}>
                    <td style={{ padding: "9px 14px", fontWeight: t.hero ? 700 : 400, color: t.hero ? C.gold : C.cream }}>{t.kw}</td>
                    <td style={{ padding: "9px 14px", fontFamily: mono, fontWeight: 700, color: pos === null ? C.slate : pos <= 10 ? C.green : pos <= 20 ? C.gold : C.red }}>
                      {pos === null ? (latest ? "—" : t.base ? `P${t.base}*` : "—") : `P${pos}`}
                    </td>
                    <td style={{ padding: "9px 14px" }}><Delta d={pv !== null && pos !== null ? pv - pos : null} /></td>
                    <td style={{ padding: "9px 14px" }}><Delta d={t.base !== null && pos !== null ? t.base - pos : null} /></td>
                    <td style={{ padding: "9px 14px" }}>
                      {cur ? <Chip text={clsLabel[cur.c]} color={C.ink} bg={clsColor[cur.c]} /> : <span style={{ color: C.slate }}>{latest ? "not found" : "baseline"}</span>}
                    </td>
                    <td style={{ padding: "9px 14px", fontFamily: mono, color: (cur?.n ?? 1) > 1 ? C.red : C.slate }}>{cur ? cur.n : "–"}</td>
                    <td style={{ padding: "9px 14px" }}>
                      {wrong ? <Chip text="WRONG PAGE" color={C.ink} bg={C.red} />
                        : legacy ? <Chip text="LEGACY" color={C.ink} bg={C.red} />
                        : pos !== null && pos <= 10 ? <Chip text="PAGE ONE" color={C.ink} bg={C.green} />
                        : <span style={{ color: C.slate, fontSize: 11 }}>{t.goal === INJ ? "→ injection page" : "→ pill page"}</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {!latest && <div style={{ padding: "8px 16px 12px", fontSize: 10.5, color: C.slate }}>*Baseline positions from the 10 June 2026 audit. First patrol replaces these with live data.</div>}
      </div>

      {/* SERP panels */}
      {latest?.serp && (
        <div style={{ display: "flex", flexWrap: "wrap", gap: 16, margin: "16px 20px 0" }}>
          {[["wp", "“wegovy pill” — live results"], ["bw", "“buy wegovy” — live results"]].map(([key, title]) => (
            <div key={key} style={{ flex: "1 1 300px", minWidth: 280, background: C.panel, border: `1px solid ${C.line}`, borderRadius: 8, padding: 14 }}>
              <Eyebrow>{title} <span style={{ color: C.slate, letterSpacing: 0, textTransform: "none", fontWeight: 400 }}>(search-API order, indicative)</span></Eyebrow>
              <div style={{ marginTop: 8 }}>
                {(latest.serp[key] || []).map((r, i) => {
                  const ours = ((r.d || "") + (r.u || "")).includes("simpleonlinepharmacy");
                  return (
                    <div key={i} style={{ display: "flex", gap: 10, padding: "6px 8px", borderRadius: 4, alignItems: "baseline", background: ours ? C.goldSoft : "transparent" }}>
                      <span style={{ fontFamily: mono, fontSize: 11, color: C.slate, width: 18 }}>{i + 1}</span>
                      <span style={{ fontSize: 12, color: ours ? C.gold : C.cream, fontWeight: ours ? 700 : 400, overflowWrap: "anywhere" }}>{r.d}{ours ? "  ← us" : ""}</span>
                    </div>
                  );
                })}
                {!(latest.serp[key] || []).some(r => ((r.d || "") + (r.u || "")).includes("simpleonlinepharmacy")) && (
                  <div style={{ marginTop: 6, fontSize: 11, color: C.red, fontFamily: mono }}>SOP absent from sampled results.</div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* remediation tracker */}
      <div style={{ margin: "16px 20px 0", background: C.panel, border: `1px solid ${C.line}`, borderRadius: 8, padding: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 8, alignItems: "baseline" }}>
          <Eyebrow>Remediation — 13 defects from the 10 June audit</Eyebrow>
          <span style={{ fontFamily: mono, fontSize: 12, color: C.gold, fontWeight: 700 }}>
            {CHECKLIST.filter(c => checks[c.id]).length}/{CHECKLIST.length} closed
          </span>
        </div>
        <div style={{ marginTop: 10, display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 8 }}>
          {CHECKLIST.map(c => {
            const done = !!checks[c.id];
            const sc = c.s === "CRIT" ? C.red : c.s === "HIGH" ? C.gold : c.s === "MED" ? C.slate : "#5B6B8C";
            return (
              <button key={c.id} onClick={() => toggleCheck(c.id)} style={{
                textAlign: "left", display: "flex", gap: 10, alignItems: "flex-start",
                background: done ? "rgba(63,167,118,0.08)" : C.panel2, border: `1px solid ${done ? C.green : C.line}`,
                borderRadius: 6, padding: "9px 10px", cursor: "pointer", color: C.cream,
              }}>
                <span style={{ fontFamily: mono, fontSize: 12, color: done ? C.green : sc, fontWeight: 800, minWidth: 34 }}>{done ? "✓" : c.s}</span>
                <span style={{ fontSize: 12, lineHeight: 1.4, textDecoration: done ? "line-through" : "none", opacity: done ? 0.55 : 1 }}>{c.t}</span>
              </button>
            );
          })}
        </div>
        <div style={{ marginTop: 10, fontSize: 11, color: C.slate }}>
          Days since audit: {Math.max(0, Math.round((Date.now() - new Date(BASE_DATE + "T00:00:00Z").getTime()) / 86400000))} ·
          critical items open: {CHECKLIST.filter(c => c.s === "CRIT" && !checks[c.id]).length}
        </div>
      </div>

      {/* log + footer */}
      <div style={{ margin: "16px 20px 0", fontSize: 11, color: C.slate, lineHeight: 1.6 }}>
        <span style={{ fontFamily: mono }}>PATROL LOG:</span>{" "}
        {snaps.length ? snaps.slice(-14).map(s => `${s.date.slice(5)} P${s.m?.pill ?? "–"}${s.mode === "search" ? "ˢ" : s.mode === "manual" ? "ᵐ" : ""}`).join(" · ") : "no runs yet"}
        <div style={{ marginTop: 8, borderTop: `1px solid ${C.line}`, paddingTop: 8 }}>
          Runs once per UK day on open. Source order: Semrush → live-search sample (ˢ, approximate) → manual entry (ᵐ).
          History persists here. Sentinel stands down when “wegovy pill” holds P1–3.
        </div>
      </div>
    </div>
  );
}
