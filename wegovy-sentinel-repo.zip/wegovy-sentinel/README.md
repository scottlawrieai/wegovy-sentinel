# Wegovy Sentinel

Zero-touch daily rank patrol for the Simple Online Pharmacy Wegovy pill cluster.
Born from the 10 June 2026 SEO audit. Runs until "wegovy pill" holds P1–3.

Every day at 07:00 UK, GitHub Actions:

1. Pulls live UK positions for the tracked Wegovy/semaglutide cluster from the Semrush API
2. Pulls the pill page's backlink referring-domain count
3. Re-runs the structural audit — wrong-page routing on "buy wegovy", legacy URL still ranking, cannibalisation count — with day-streak counters on every open defect
4. Commits the snapshot to `data/snapshots.json` (and `docs/snapshots.json` for the dashboard)
5. Posts the digest to Slack

The dashboard at GitHub Pages renders the altimeter, flags, keyword table and 30-day trend from the committed history. No servers, no databases — the repo is the database.

## Deploy (5 minutes)

1. **Create the repo.** New private repo on GitHub (e.g. `wegovy-sentinel`), then from this folder:

   ```bash
   git remote add origin git@github.com:YOUR_ORG/wegovy-sentinel.git
   git push -u origin main
   ```

2. **Add secrets.** Repo → Settings → Secrets and variables → Actions:
   - `SEMRUSH_API_KEY` — semrush.com → Profile → API. Required.
   - `SLACK_WEBHOOK_URL` — Slack incoming webhook for the growth channel. Optional but the point.

3. **Enable the dashboard.** Settings → Pages → Source: `main` branch, `/docs` folder. URL appears in ~1 minute.

4. **Seed day zero.** Actions tab → "Daily patrol" → Run workflow. Check Slack and the Pages URL.

5. **Done.** Cron fires 06:00 UTC daily (07:00 BST / 06:00 GMT). A red run = Semrush failure, and the failure itself is posted to Slack — silence is never ambiguous.

## Notes

- **Semrush API units:** each patrol costs roughly 100–150 API units (two `domain_organic` pulls + one `backlinks_overview`). Negligible against a Business plan allowance.
- **Backlinks API** is a separate Semrush subscription on some plans. If unavailable, the script logs a warning and reports 0 — everything else still runs.
- **Targets** (from the audit): top 10 for "wegovy pill" within 60 days; P1–3 by MHRA decision; injection page P1–5 on "buy wegovy" within 30 days of consolidation; ≥15 referring domains to the pill page.
- `claude-artifact/wegovy-sentinel.jsx` is the interactive Claude artifact version (Semrush MCP + manual mode) for ad-hoc use inside Claude.
- Self-test without touching Semrush: `python sentinel.py --test`

## Tracked cluster

wegovy pill · wegovy pills · wegovy tablets · wegovy pill uk · buy wegovy pills · oral semaglutide · buy wegovy · buy wegovy online · buy wegovy uk · where can i buy wegovy uk

Baseline (10 Jun 2026): pill page P26 on "wegovy pill"; "buy wegovy" served by the wrong page at P9; legacy URL live; 0 backlinks.
